export interface Todo {
    title: string;
    description: string;
    id: string;
    done: boolean;
}