alter table "auth"."friendships" alter column "user1_spam_user2" drop not null;
