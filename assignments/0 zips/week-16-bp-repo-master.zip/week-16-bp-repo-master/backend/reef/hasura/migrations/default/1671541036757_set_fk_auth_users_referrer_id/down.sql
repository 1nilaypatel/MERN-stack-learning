alter table "auth"."users" drop constraint "users_referrer_id_fkey";
