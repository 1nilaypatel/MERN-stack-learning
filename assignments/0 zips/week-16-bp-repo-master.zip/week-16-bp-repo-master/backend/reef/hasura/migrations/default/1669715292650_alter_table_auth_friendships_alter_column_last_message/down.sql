alter table "auth"."friendships" alter column "last_message" set not null;
