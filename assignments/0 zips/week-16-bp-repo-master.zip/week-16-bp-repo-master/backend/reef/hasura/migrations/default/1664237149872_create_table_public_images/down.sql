DROP TABLE "public"."images";
