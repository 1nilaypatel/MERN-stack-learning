alter table "appstore"."pending_curator_reviews" alter column "created_at" set default now();
