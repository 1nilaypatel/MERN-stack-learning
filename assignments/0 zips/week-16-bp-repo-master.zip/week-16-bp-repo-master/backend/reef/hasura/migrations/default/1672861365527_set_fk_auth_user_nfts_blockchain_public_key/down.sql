alter table "auth"."user_nfts" drop constraint "user_nfts_blockchain_public_key_fkey";
