alter table "auth"."users" add column "spam_count" integer
 null default '0';
