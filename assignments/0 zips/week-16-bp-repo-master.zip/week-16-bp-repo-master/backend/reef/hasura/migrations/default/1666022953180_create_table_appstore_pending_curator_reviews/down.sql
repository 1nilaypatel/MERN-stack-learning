DROP TABLE "appstore"."pending_curator_reviews";
