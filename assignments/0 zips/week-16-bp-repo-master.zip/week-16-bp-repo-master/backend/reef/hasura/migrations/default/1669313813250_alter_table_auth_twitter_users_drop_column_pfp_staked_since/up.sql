alter table "auth"."twitter_users" drop column "pfp_staked_since" cascade;
