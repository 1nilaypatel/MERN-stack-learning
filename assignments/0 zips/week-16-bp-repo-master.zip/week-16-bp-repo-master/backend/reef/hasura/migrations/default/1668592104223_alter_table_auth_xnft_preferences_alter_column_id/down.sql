alter table "auth"."xnft_preferences" rename column "id2" to "id";
