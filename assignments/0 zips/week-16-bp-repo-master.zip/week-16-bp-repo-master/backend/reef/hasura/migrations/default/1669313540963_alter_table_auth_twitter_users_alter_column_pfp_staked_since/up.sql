ALTER TABLE "auth"."twitter_users" ALTER COLUMN "pfp_staked_since" TYPE time without time zone;
