alter table "auth"."mad_feed_posts" rename column "thumbnail_metadata" to "image_metadata";
