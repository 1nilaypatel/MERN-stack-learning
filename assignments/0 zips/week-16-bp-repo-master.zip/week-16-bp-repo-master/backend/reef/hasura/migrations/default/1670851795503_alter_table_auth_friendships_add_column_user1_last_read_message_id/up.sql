alter table "auth"."friendships" add column "user1_last_read_message_id" text
 null;
