DROP TABLE "auth"."collection_messages";
