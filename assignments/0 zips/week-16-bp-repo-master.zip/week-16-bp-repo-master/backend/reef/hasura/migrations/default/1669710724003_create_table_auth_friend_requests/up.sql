CREATE TABLE "auth"."friend_requests" ("from" text NOT NULL, "to" text NOT NULL, "id" serial NOT NULL, PRIMARY KEY ("id") );
