CREATE TABLE "auth"."collections" ("id" serial NOT NULL, "type" text NOT NULL, "collection_id" text, "last_message_uuid" text, PRIMARY KEY ("id") );
