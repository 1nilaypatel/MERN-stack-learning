alter table "auth"."user_nfts" alter column "blockchain" set not null;
