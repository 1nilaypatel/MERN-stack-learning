alter table "auth"."collections" add column "last_message" text
 null;
