DROP FUNCTION IF EXISTS "auth"."create_invitation_for_image_record" CASCADE;
