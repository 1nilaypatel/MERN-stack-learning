DROP TABLE "auth"."users";
