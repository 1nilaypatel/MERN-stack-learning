alter table "auth"."friendships" rename column "last_message_client_uuid" to "last_message_id";
