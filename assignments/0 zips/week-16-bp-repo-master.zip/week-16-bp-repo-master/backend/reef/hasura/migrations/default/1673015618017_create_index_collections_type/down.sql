DROP INDEX IF EXISTS "auth"."collections_type";
