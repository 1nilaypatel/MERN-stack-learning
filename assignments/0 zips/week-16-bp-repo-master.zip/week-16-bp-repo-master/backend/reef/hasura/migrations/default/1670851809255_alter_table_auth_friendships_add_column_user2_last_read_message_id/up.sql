alter table "auth"."friendships" add column "user2_last_read_message_id" text
 null;
