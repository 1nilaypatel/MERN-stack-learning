DROP TABLE "auth"."xnft_preferences";
