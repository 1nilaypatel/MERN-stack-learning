alter table "auth"."friendships" rename column "last_message_id" to "last_message_client_uuid";
