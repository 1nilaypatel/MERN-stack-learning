alter table "auth"."users" drop column "blockchain" cascade;
