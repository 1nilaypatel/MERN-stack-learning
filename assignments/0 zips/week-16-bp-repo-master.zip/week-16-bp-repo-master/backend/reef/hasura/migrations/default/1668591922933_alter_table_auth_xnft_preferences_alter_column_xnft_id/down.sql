ALTER TABLE "auth"."xnft_preferences" ALTER COLUMN "xnft_id" TYPE boolean;
