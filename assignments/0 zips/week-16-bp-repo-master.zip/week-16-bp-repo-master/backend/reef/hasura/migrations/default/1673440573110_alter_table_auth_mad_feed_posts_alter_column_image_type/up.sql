alter table "auth"."mad_feed_posts" rename column "image_type" to "thumbnail_type";
