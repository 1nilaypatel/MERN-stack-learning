alter table "auth"."users" drop column "spam_count" cascade;
