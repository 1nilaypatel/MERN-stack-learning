alter table "auth"."users" add column "avatar_nft" citext
 null;
