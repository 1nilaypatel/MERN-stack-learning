alter table "auth"."users" drop column "blockchain";

drop type blockchain;
