CREATE TABLE "auth"."xnft_secrets" ("id" serial NOT NULL, "xnft_id" text NOT NULL, "secret" text NOT NULL, PRIMARY KEY ("id") );
