alter table "appstore"."pending_curator_reviews" add constraint "pending_curator_reviews_xnft_key" unique ("xnft");
