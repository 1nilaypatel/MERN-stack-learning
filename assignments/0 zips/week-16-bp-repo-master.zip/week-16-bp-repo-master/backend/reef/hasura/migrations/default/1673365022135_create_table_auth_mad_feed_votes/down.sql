DROP TABLE "auth"."mad_feed_votes";
