alter table "auth"."friendships" add column "user2_spam_user1" boolean
 not null default 'false';
