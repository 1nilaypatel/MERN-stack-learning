alter table "appstore"."pending_curator_reviews" drop constraint "pending_curator_reviews_xnft_key";
