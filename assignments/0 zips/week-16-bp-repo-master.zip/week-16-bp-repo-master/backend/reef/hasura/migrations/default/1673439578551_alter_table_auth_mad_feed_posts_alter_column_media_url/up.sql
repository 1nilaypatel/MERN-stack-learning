alter table "auth"."mad_feed_posts" rename column "media_url" to "image_url";
