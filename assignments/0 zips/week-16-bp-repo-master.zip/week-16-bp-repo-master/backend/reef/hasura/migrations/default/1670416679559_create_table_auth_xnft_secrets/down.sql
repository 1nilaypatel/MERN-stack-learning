DROP TABLE "auth"."xnft_secrets";
