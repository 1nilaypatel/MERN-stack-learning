alter table "auth"."mad_feed_posts" add column "image_metadata" json
 null;
