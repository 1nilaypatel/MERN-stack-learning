alter table "appstore"."pending_curator_reviews" rename column "ix_data" to "transaction";
