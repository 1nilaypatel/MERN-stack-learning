alter table "auth"."friendships" add column "last_message_id" text
 null;
