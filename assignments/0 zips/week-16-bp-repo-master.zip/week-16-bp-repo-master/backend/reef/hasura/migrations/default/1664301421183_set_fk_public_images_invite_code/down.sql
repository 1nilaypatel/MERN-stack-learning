alter table "public"."images" drop constraint "images_invite_code_fkey";
