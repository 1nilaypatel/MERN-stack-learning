alter table "auth"."user_nfts" add column "blockchain" text
 null default 'solana';
