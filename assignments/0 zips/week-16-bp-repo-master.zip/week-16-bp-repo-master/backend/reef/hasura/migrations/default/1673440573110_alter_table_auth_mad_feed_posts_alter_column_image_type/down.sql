alter table "auth"."mad_feed_posts" rename column "thumbnail_type" to "image_type";
