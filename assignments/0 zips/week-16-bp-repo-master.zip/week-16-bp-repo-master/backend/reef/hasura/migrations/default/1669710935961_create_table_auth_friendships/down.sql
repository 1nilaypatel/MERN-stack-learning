DROP TABLE "auth"."friendships";
