alter table "public"."images" add column "winner" text
 null;
