alter table "auth"."stripe_onramp" rename column "publicKey" to "public_key";
