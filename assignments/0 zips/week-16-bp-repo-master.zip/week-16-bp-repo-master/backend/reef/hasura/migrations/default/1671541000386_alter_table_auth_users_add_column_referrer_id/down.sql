alter table "auth"."users" drop column "referrer_id";
