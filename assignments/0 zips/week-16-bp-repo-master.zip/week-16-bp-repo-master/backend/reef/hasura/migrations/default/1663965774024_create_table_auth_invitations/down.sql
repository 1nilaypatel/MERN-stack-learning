DROP TABLE "auth"."invitations";
