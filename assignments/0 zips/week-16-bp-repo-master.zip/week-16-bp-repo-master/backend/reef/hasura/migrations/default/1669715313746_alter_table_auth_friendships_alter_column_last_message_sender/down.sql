alter table "auth"."friendships" alter column "last_message_sender" set not null;
