alter table "auth"."mad_feed_posts" rename column "thumbnail_url" to "image_url";
