DROP TABLE "auth"."user_nfts";
