DROP INDEX IF EXISTS "auth"."collections_collection_id_type_key";
