alter table "auth"."mad_feed_posts" rename column "image_type" to "media_type";
