alter table "appstore"."pending_curator_reviews" add column "ix_keys" jsonb
 not null;
