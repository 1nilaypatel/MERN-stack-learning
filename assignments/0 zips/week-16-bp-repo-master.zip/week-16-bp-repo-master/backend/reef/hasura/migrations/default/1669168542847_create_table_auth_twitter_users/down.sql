DROP TABLE "auth"."twitter_users";
