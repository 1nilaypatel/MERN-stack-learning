alter table "appstore"."pending_curator_reviews" add column "transaction" bytea
 not null;
