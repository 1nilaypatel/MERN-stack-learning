alter table "auth"."xnft_preferences" rename column "id" to "id2";
