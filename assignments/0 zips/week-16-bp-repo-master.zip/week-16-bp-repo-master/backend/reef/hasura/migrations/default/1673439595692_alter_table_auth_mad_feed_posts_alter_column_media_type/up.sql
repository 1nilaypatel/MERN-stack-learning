alter table "auth"."mad_feed_posts" rename column "media_type" to "image_type";
