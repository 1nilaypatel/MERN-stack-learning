alter table "auth"."notification_subscriptions" add column "uuid" text
 not null;
