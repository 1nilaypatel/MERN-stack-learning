alter table "auth"."xnft_preferences" add column "id" serial
 not null;
