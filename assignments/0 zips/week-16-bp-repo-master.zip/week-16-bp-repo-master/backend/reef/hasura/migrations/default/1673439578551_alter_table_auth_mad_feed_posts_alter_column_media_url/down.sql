alter table "auth"."mad_feed_posts" rename column "image_url" to "media_url";
