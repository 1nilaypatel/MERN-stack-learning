alter table "auth"."friendships" alter column "last_message_timestamp" drop not null;
