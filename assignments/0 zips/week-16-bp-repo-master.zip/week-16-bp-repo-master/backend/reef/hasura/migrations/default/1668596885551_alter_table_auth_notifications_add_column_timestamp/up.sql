alter table "auth"."notifications" add column "timestamp" timestamptz
 null;
