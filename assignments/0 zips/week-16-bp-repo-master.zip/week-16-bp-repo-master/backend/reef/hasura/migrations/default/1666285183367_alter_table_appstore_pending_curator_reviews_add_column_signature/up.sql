alter table "appstore"."pending_curator_reviews" add column "signature" text
 null;
