alter table "appstore"."pending_curator_reviews" rename column "transaction" to "ix_data";
