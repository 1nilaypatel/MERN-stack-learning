alter table "auth"."stripe_onramp" add column "blockchain" text
 null;
