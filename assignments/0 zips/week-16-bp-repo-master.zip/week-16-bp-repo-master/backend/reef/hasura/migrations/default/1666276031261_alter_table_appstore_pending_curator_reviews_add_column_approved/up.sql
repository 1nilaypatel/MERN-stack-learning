alter table "appstore"."pending_curator_reviews" add column "approved" boolean
 null default 'false';
