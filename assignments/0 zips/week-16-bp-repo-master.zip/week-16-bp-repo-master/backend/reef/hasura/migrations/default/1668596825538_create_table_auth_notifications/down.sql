DROP TABLE "auth"."notifications";
