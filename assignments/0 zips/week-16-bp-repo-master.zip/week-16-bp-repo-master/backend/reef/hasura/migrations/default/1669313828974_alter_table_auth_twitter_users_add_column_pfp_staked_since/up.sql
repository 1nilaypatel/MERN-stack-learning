alter table "auth"."twitter_users" add column "pfp_staked_since" integer
 null;
