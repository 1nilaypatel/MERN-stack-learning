DROP TABLE "auth"."collections";
