alter table "auth"."stripe_onramp" rename column "public_key" to "publicKey";
