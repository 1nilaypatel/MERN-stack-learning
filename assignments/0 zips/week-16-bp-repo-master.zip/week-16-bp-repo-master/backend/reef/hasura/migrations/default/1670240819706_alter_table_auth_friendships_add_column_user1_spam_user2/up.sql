alter table "auth"."friendships" add column "user1_spam_user2" boolean
 null default 'false';
