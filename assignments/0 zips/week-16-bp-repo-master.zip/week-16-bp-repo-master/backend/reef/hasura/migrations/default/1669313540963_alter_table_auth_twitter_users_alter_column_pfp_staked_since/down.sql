ALTER TABLE "auth"."twitter_users" ALTER COLUMN "pfp_staked_since" TYPE timestamp with time zone;
