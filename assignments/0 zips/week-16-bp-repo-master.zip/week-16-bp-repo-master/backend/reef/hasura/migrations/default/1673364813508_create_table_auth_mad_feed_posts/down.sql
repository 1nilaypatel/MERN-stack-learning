DROP TABLE "auth"."mad_feed_posts";
