alter table "auth"."friendships" alter column "last_message_timestamp" set not null;
