alter table "appstore"."pending_curator_reviews" add column "processed" boolean
 null default 'false';
