DROP TABLE "auth"."notification_subscriptions";
