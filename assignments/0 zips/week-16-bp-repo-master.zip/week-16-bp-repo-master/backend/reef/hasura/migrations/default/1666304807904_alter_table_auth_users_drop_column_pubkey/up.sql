alter table "auth"."users" drop column "pubkey" cascade;
