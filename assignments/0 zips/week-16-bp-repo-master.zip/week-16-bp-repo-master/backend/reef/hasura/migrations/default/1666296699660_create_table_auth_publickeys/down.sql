DROP TABLE "auth"."publickeys_history";
