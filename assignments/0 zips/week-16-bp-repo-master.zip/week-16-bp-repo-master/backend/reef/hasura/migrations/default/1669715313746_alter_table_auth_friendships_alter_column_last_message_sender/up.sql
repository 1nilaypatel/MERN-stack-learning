alter table "auth"."friendships" alter column "last_message_sender" drop not null;
