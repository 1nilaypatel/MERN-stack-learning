DROP TABLE "auth"."stripe_onramp";
