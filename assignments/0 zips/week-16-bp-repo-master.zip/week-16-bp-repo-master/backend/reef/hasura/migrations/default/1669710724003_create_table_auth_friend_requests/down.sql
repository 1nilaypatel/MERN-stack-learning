DROP TABLE "auth"."friend_requests";
