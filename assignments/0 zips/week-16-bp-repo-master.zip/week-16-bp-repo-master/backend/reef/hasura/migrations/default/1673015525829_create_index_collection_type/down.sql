DROP INDEX IF EXISTS "auth"."collection_type";
