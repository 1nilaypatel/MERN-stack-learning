alter table "auth"."users" add column "referrer_id" uuid
 null;
