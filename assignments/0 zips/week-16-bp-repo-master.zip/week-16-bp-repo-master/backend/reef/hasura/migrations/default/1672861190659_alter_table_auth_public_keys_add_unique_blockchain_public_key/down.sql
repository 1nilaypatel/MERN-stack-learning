alter table "auth"."public_keys" drop constraint "public_keys_blockchain_public_key_key";
