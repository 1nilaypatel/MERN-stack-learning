ALTER TABLE "appstore"."pending_curator_reviews" ALTER COLUMN "created_at" drop default;
