DROP TABLE "auth"."waolist_tokens";
