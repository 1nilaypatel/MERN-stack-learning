alter table "public"."secure_transfer_transactions" drop constraint "secure_transfer_transactions_message_id_fkey";
