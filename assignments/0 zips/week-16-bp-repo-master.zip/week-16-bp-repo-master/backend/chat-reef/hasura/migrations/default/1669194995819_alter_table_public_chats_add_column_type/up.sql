alter table "public"."chats" add column "type" text
 not null;
