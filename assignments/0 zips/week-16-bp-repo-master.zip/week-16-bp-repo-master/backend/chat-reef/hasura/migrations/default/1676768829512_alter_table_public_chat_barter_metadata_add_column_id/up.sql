alter table "public"."chat_barter_metadata" add column "id" serial
 not null;
