alter table "public"."secure_transfer_transactions" add column "final_txn_signature" text
 null;
