CREATE TABLE "public"."secure_transfer_transactions" ("id" serial NOT NULL, "counter" text NOT NULL, "from" text NOT NULL, "to" text NOT NULL, PRIMARY KEY ("id") );
