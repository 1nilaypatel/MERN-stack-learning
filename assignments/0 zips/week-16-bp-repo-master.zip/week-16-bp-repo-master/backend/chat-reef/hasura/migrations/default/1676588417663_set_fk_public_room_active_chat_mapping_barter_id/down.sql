alter table "public"."room_active_chat_mapping" drop constraint "room_active_chat_mapping_barter_id_fkey";
