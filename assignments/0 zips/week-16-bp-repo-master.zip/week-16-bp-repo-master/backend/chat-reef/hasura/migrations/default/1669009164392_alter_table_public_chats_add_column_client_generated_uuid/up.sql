alter table "public"."chats" add column "client_generated_uuid" text
 not null;
