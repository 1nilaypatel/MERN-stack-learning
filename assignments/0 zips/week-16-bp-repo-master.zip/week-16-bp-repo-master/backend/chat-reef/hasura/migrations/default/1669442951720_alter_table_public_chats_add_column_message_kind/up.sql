alter table "public"."chats" add column "message_kind" text
 null;
