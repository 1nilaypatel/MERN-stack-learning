alter table "public"."chats" add column "parent_client_generated_uuid" text
 null;
