alter table "public"."chats" add column "uuid" text
 null;
