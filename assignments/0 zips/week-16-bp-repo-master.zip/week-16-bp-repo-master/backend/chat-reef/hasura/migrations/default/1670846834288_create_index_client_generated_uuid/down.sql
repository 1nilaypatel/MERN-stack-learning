DROP INDEX IF EXISTS "public"."client_generated_uuid";
