CREATE TABLE "public"."chat_media_messages" ("id" serial NOT NULL, "media_kind" text NOT NULL, "media_link" text NOT NULL, "message_client_generated_uuid" text NOT NULL, PRIMARY KEY ("id") );
