DROP TABLE "public"."barters";
