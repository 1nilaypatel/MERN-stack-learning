alter table "public"."chat_barter_metadata" drop constraint "chat_barter_metadata_barter_id_fkey";
