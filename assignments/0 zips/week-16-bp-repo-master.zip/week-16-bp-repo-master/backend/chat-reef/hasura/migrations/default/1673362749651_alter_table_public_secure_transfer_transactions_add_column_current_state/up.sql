alter table "public"."secure_transfer_transactions" add column "current_state" text
 null;
