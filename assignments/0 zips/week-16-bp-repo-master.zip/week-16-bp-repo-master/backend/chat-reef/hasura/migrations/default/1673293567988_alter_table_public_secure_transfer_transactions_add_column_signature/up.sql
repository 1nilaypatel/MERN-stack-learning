alter table "public"."secure_transfer_transactions" add column "signature" text
 null;
