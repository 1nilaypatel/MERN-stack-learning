alter table "public"."chats" add column "room" text
 null;
