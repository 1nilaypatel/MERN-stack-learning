DROP TABLE "public"."secure_transfer_transactions";
