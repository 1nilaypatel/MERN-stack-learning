CREATE TABLE "public"."chats" ("id" serial NOT NULL, "message" text NOT NULL, PRIMARY KEY ("id") );
