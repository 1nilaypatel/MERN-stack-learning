DROP TABLE "public"."barter_poke_metadata";
