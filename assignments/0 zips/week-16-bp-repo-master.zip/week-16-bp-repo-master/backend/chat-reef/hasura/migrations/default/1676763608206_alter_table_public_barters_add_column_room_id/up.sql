alter table "public"."barters" add column "room_id" text
 null;
