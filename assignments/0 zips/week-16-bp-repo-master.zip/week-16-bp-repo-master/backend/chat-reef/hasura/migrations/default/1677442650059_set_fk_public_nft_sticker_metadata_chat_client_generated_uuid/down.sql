alter table "public"."nft_sticker_metadata" drop constraint "nft_sticker_metadata_chat_client_generated_uuid_fkey";
