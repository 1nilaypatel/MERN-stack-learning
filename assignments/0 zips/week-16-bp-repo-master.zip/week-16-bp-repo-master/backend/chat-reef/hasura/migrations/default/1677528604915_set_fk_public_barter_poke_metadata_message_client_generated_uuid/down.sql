alter table "public"."barter_poke_metadata" drop constraint "barter_poke_metadata_message_client_generated_uuid_fkey";
