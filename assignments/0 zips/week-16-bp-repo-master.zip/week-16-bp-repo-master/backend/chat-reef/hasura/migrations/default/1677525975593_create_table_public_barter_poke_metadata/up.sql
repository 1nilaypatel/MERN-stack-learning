CREATE TABLE "public"."barter_poke_metadata" ("id" serial NOT NULL, "message_client_generated_uuid" text NOT NULL, "barter_id" integer NOT NULL, PRIMARY KEY ("id") );
