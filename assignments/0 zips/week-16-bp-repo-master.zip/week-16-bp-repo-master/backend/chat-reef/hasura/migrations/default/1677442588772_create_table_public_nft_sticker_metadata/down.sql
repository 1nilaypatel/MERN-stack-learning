DROP TABLE "public"."nft_sticker_metadata";
