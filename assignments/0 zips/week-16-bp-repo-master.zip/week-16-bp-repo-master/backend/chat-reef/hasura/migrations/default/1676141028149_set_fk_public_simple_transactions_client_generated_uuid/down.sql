alter table "public"."simple_transactions" drop constraint "simple_transactions_client_generated_uuid_fkey";
