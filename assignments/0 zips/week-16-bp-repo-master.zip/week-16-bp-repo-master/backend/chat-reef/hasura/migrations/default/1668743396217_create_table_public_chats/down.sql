DROP TABLE "public"."chats";
