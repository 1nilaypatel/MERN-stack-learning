alter table "public"."chats" drop constraint "chats_client_generated_uuid_key";
