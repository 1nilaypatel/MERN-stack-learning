alter table "public"."secure_transfer_transactions" add column "message_id" text
 not null;
