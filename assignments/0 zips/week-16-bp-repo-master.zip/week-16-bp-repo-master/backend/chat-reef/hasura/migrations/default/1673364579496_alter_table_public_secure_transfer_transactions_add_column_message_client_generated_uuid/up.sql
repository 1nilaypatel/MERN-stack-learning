alter table "public"."secure_transfer_transactions" add column "message_client_generated_uuid" text
 null;
