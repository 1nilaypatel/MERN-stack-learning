DROP TABLE "public"."room_active_chat_mapping";
