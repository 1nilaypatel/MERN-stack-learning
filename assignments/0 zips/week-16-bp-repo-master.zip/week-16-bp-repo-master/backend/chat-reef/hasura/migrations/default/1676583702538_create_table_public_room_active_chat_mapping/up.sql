CREATE TABLE "public"."room_active_chat_mapping" ("barter_id" integer NOT NULL, "room_id" text NOT NULL, PRIMARY KEY ("room_id") );
