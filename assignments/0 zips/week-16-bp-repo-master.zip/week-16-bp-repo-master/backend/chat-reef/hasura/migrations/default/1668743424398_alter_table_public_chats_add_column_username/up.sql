alter table "public"."chats" add column "username" text
 null;
