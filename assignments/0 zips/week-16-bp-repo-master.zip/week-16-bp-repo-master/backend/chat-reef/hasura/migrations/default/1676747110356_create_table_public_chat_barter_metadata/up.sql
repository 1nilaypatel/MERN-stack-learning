CREATE TABLE "public"."chat_barter_metadata" ("chat_client_generated_uuid" text NOT NULL, "barter_id" integer NOT NULL, PRIMARY KEY ("chat_client_generated_uuid") );
