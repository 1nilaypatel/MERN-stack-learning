CREATE  INDEX "client_generated_uuid" on
  "public"."chats" using btree ("client_generated_uuid");
