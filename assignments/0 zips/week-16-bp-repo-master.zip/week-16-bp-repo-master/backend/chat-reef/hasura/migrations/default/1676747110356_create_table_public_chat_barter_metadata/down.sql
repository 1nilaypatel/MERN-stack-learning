DROP TABLE "public"."chat_barter_metadata";
