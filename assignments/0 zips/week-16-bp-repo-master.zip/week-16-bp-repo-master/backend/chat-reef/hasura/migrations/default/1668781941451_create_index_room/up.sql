CREATE  INDEX "room" on
  "public"."chats" using btree ("room");
