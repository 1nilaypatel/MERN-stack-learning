alter table "public"."chats" add constraint "chats_client_generated_uuid_key" unique ("client_generated_uuid");
