alter table "public"."chats" add column "deleted" boolean
 null default 'false';
