DROP TABLE "public"."chat_media_messages";
