alter table "public"."secure_transfer_transactions" drop constraint "secure_transfer_transactions_message_client_generated_uuid_f";
