alter table "public"."secure_transfer_transactions" drop column "message_id" cascade;
