DROP TABLE "public"."chat_update_history";
