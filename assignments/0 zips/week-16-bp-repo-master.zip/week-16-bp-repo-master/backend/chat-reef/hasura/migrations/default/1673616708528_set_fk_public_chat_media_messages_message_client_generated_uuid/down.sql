alter table "public"."chat_media_messages" drop constraint "chat_media_messages_message_client_generated_uuid_fkey";
