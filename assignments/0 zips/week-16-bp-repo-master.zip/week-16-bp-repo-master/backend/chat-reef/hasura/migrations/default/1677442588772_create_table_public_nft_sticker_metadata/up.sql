CREATE TABLE "public"."nft_sticker_metadata" ("chat_client_generated_uuid" text NOT NULL, "id" serial NOT NULL, "mint" text NOT NULL, PRIMARY KEY ("id") );
