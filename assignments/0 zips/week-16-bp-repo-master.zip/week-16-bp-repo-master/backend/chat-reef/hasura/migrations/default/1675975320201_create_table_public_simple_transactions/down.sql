DROP TABLE "public"."simple_transactions";
