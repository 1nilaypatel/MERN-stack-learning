alter table "public"."secure_transfer_transactions" add column "escrow" text
 not null;
