CREATE TABLE "public"."simple_transactions" ("id" serial NOT NULL, "txn_signature" text NOT NULL, "client_generated_uuid" text NOT NULL, PRIMARY KEY ("id") );
