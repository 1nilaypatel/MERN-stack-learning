alter table "public"."chat_barter_metadata" drop constraint "chat_barter_metadata_chat_client_generated_uuid_fkey";
