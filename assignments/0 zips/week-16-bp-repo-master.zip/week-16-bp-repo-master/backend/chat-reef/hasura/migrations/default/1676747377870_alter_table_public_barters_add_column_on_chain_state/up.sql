alter table "public"."barters" add column "on_chain_state" text
 null;
