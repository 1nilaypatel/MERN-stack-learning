
export const USER = "USER";