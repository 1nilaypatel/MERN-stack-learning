export const Errors = {
  AUTH_ERROR: "Authorization error",
  INCORRECT_INPUT_ERROR: "Incorrect input params",
  NO_XNFT_FOUND: "No xnft found with given secret",
};
