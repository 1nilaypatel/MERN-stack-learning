"use client";

export const Button = () => {
  return <button onClick={() => alert("boop11")}>Boop</button>;
};
