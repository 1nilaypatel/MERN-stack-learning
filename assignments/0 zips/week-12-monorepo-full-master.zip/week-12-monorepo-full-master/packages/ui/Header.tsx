
export const Header = ({ text }: { text: string }) => {
  return <h1>{text}</h1>;
};
