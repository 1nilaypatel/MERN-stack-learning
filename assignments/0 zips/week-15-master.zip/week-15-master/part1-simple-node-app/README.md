## Simple node.js app with docker


### Helpful commands

```
docker build . -t simple-app
```

```
docker run simple-app
```

```
docker ps
```

```
docker images
```

