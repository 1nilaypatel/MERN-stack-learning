## Simple node.js app with docker


### Helpful commands

```
docker build . -t simple-app2
```

```
docker run simple-app2
```

```
docker ps
```

```
docker images
```

