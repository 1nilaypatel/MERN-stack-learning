
export function LandingPage() {
    return <div>
        Hi welcome to landing page
    </div>
}