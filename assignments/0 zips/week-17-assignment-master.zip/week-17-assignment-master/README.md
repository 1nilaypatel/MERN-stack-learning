Create a simple Websocket server that can support 3 types of actions

Spawn an avatar at a position
Move an avatar around
Answer where the avatar is 

Please try going through the src/index.ts to understand the kind of things your server needs to do


