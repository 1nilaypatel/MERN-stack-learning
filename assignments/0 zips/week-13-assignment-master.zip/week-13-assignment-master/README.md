## Migrate TODO application  to Postgres
 - Take the base code from https://github.com/100xDevs-hkirat/week-8-repo
 - Add prisma as the ORM
 - Replace all mongoose calls with calls to postgres va Prisma
 - Ensure at the end that you are able to see data in Postgres

## Hard todo
 - Now do the same for a monorepo
 - You can take the base code from https://github.com/100xDevs-hkirat/week-11-class
 - db is the module where you'll need to make the changes
 - Can you figure out how you can run prisma migrations from the root folder somehow? Try looking at the cal.com codebase to see how they do it  
