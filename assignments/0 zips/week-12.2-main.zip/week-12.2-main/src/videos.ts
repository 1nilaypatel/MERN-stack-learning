export interface Video {
    title: string;
    thumbnail: string;
    description: string;
    viewCount: string;
    timestamp: string;
}

export const VIDEOS: Video[] = [
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    },
    {
        title: "New song",
        thumbnail: "/video1.jpg",
        description: "Mix Song of 2023 with dance and singing it in full stream",
        viewCount: "1.3k",
        timestamp: "4 hours ago"
    }
]