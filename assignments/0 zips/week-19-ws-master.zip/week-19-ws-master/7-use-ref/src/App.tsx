import React, { useRef } from 'react';
import './App.css'
import { BadInput } from "./BadInput";
import {GoodInput} from "./GoodInput";

function App() {
    // return <BadInput />
    return <GoodInput />
}

export default App
