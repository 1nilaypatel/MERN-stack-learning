
### Assignment 1
Create the frontend for a TODO app. 
You should be able to 
1. Create a new TODO
2. List all TODOs
3. Delete a TODO

The backend we've already written in 
/week2/02-nodejs/solutions/todoServer.solution.js

Make sure you
1. Add app.listen so it is running on 3000
2. Use cors

Good to do
1. Break things down into components
2. Use a library like axios to make the requests
