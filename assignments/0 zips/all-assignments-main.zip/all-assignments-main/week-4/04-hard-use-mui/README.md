### Using mui
Go through the docs at https://mui.com

This is a library that has a lot of pre-defined components that you can use
This is the power of components, you can use them to build your own components.
Try replacing buttons and input boxes with mui's implementation and see how pretty your app looks with 0 effort.
