We have ~2 medium-ish assignments this week
1. Convert a JS backend to TS
2. Convert a JS react app to TS

First one might feel more difficult than the second one because we're creating a tsconfig file, moving all our files to TS and then fixing all the errors. 
The second one might feel easier since we're using vite to simply bootstrap the project, and then moving files over.

The goal of this week is to get you comfortable with TS, and to show you how to move a JS project to TS.

If you feel you're getting overwhelmed, you dont have to do the assignment. You can wait for the solution to be released, and then follow along with the solution.

This weeks assigment is slightly hard, and I would urge you to use TAs support throughout the week.