You have the janky version of a reconciler. It's not very good. It's not very fast. But it's a start.
In the 3.2 video we discuss how we can make it faster.
Can you figure out how to make it faster?
By faster we mean minimizing the number of DOM interactions.
Feel free to look at the tests for a hint
