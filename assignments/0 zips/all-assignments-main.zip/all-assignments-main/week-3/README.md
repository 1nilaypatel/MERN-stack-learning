This week we wrapped up most of backend. 
We'll also be posting about DBs and auth in a video so the assignment has questions from that as well. 
Feel free to do them right now or after the video is posted.
